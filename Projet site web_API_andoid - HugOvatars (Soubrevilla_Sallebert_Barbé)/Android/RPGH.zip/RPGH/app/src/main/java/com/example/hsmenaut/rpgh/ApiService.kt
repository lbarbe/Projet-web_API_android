package com.example.hsmenaut.rpgh

import android.database.Observable
import org.json.JSONObject
import retrofit2.CallAdapter
import retrofit2.http.GET
import retrofit2.Retrofit
import retrofit2.http.Query
import retrofit2.Converter

interface ApiService {

    @GET("api.php")
    fun hitCountCheck(@Query("action") action: String,
                      @Query("format") format: String,
                      @Query("list") list: String,
                      @Query("srsearch") srsearch: String): Observable<Model.Result>

    companion object {
        fun create(): ApiService {

            val retrofit = Retrofit.Builder()
                    .baseUrl("https://bhlprojet-lbarbe.c9users.io/BHLprojet/public/API")
                    .build()

            return retrofit.create(ApiService::class.java)
        }
    }

}