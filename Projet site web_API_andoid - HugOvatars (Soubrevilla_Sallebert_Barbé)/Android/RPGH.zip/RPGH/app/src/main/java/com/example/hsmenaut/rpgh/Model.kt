package com.example.hsmenaut.rpgh

object Model {
    data class Result(val apiVersion: String, val sizes: String, val defaultSize: String, val formats: String)
}