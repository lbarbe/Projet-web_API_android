package com.example.hsmenaut.rpgh

import android.graphics.drawable.Drawable
import android.hardware.Sensor
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.hardware.SensorManager
import kotlinx.android.synthetic.main.activity_main.*
import android.view.View
import com.squareup.picasso.Picasso
import java.net.URL
import java.net.HttpURLConnection
import java.security.MessageDigest
import org.jetbrains.anko.*
import android.os.AsyncTask.execute
import android.util.Log
import org.apache.http.client.HttpClient
import java.io.BufferedInputStream


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Submit.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {

//                Picasso.get().load("https://bhlprojet-lbarbe.c9users.io/BHLprojet/public/avatars/" + champEmail.text).into(imageView);

                fun sha256(text: String): String {
                    val bytes = text.toByteArray()
                    val md = MessageDigest.getInstance("SHA-256")
                    val digest = md.digest(bytes)
                    return digest.fold("", { str, it -> str + "%02x".format(it) })
                }
                val mail = champEmail.text.toString()
                val mailSalted = sha256(mail)
                val urlBase = "https://bhlprojet-lbarbe.c9users.io/BHLprojet/public/"
                val urlImageBase = urlBase + "avatars/"
                Picasso.get()
                        .load(urlImageBase + mailSalted)
                        .into(imageView);


//                val httpclient = DefaultHttpClient()
//                val httpget = HttpGet("https://bhlprojet-lbarbe.c9users.io/BHLprojet/public/API")
//
//                val response = httpclient.execute(httpget)
//
//                if (response.getStatusLine().getStatusCode() === 200) {
//                    val server_response = EntityUtils.toString(response.getEntity())
//                    Log.i("Server response", server_response)
//                } else {
//                    Log.i("Server response", "Failed to get server response")
//                }


                val url = URL("http://www.android.com/")
                val urlConnection = url.openConnection() as HttpURLConnection
                try {
                    val `in` = BufferedInputStream(urlConnection.inputStream)
                    readStream(`in`)
                } finally {
                    urlConnection.disconnect()
                }




            }
        })

    }


}
