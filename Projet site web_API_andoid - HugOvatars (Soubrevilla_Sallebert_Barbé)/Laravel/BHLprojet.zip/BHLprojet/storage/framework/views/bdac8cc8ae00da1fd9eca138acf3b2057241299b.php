<?php $__env->startSection('content'); ?>
    <div id="container">
        <div id="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Ajouter un avatar</div>
                    <div class="panel-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php foreach($errors->all() as $error): ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    
                        <?php echo Form::open(array('route' => 'avatars.store', 'files' => true, 'method' => 'post')); ?>

                            <?php echo Form::label('mail', 'Votre adresse mail'); ?>

                            <?php echo Form::email('mail', '', ['class' => 'form-control']); ?><br />
                            <?php echo Form::label('image', 'Votre avatar'); ?>

                            <?php echo Form::file('image', ['class' => 'form-control-file']); ?>

                            <?php echo Form::submit('Envoyer !', ['id' => 'send', 'class' => 'btn btn-primary mb-2']); ?><br/><br />
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>