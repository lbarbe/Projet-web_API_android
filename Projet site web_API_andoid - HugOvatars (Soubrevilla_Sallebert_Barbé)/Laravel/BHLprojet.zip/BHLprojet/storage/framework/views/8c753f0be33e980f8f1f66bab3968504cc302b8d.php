<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php echo $__env->yieldContent('nomUtilisation'); ?>
    </div>
     <div class="row">
        <?php echo $__env->yieldContent('listeAvatars'); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>