<?php $__env->startSection('nomUtilisation'); ?>
<div class="container">
    l'email 
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('option'); ?>
<div class="container">
    les options 
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeAvatars'); ?>
<div class="container">
    la liste des Avatarss
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterProfil', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>