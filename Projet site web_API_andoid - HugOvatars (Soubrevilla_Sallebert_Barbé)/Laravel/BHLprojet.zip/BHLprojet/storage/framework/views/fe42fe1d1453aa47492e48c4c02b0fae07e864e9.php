<?php $__env->startSection('nomUtilisation'); ?>
<div id="row">
    <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
            <div class="panel-heading">
                Vous etes connecté en tant que : <?php echo e(Auth::user()->name); ?>.</div>
            <div class="panel-body">
                Voici votre liste d'avatars avec les adresses mails correspondant</div>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeAvatars'); ?>
                    
    </br>
    <div class="container" id="avatarsContainer">
        <?php echo Form::open(array('route' => 'deleteAvatars', 'method' => 'post')); ?>

            <div class="row">
                <div class="col-md-2 col-md-offset-10">
                    <input type="submit" value="Supprimer sélection" class="btn btn-primary mb-2" id="JeanJacques" onClick="if(confirm('Voulez-vous vraiment supprimer les images sélectionnées ?')) commentDelete(1); return false">
                </div>
            </div>
            <div class="row">
                <?php foreach($emails as $email): ?>
                    <div class="col-md-3">
                        <label class="containerCheck">
                            <?php echo Form::checkbox('ch[]', $email->mail , false); ?>

                            <span class="checkmark"></span>
                            <img src="<?php echo $email->link; ?>" alt="" class="card-img-top" width="100px" height="100px"/>
                        </label>
                        <h5 class="img-title"><a href="<?php echo e(url('/formEmail/'.str_replace('/', '', $email->mail))); ?>"><?php echo $email->mail_aff; ?></a></h5>
                    </div>
                <?php endforeach; ?>
                    <div class="col-md-3">
                        <a href="<?php echo e(url('/formEmail')); ?>"><img src="/BHLprojet/resources/assets/images/+.png" alt="" class="card-img-top" width="100px" height="100px" /></a>
                        <h5 class="img-title"><a href="<?php echo e(url('/formEmail')); ?>">Ajouter</a></h5>
                    </div>
             </div>
         <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterProfile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>